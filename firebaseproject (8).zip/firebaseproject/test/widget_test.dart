import 'package:firebaseproject/Home.dart';
import 'package:firebaseproject/productbox.dart';
import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:firebase_core/firebase_core.dart';

void main() async {
  setUpAll(() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp(
    options: const FirebaseOptions(
      apiKey: 'AIzaSyDMyybDx2f33w9QqhwnNRX8ftbQl2f8yJI',
      appId: '1:662637659615:android:60c9a1f7198f118efb306a',
      messagingSenderId: '662637659615',
      projectId: 'nayem-7e9a1',
      storageBucket: 'nayem-7e9a1.appspot.com',
    ),
  );});

  testWidgets('Balance Display Test', (WidgetTester tester) async {
    print("wew");
    await tester.pumpWidget(
      MaterialApp(
        home: Home(title: "Shaker Maker", username: "meepmeep", password: "12345"),
      ),
    );
    expect(find.text('Balance: \$971.54'), findsOneWidget);
  });

  testWidgets('ProductBox Testing', (WidgetTester tester) async {
    await tester.pumpWidget(
      MaterialApp(
        home: Scaffold(
          body: Directionality(
            textDirection: TextDirection.ltr,
            child: ProductBox(
              name: 'mobile shake',
              description: 'perfect',
              price: 8.0,
              image: 'one.png',
              userbalance: 971.54,
              updateBalanceCallback: (double newBalance) {},
              count: 10,
              countUpdater: (int newCount) {},
              username: 'meepmeep',
            ),
          ),
        ),
      ),
    );
    expect(find.text('Price: \$8.00'), findsOneWidget);
    await tester.tap(find.widgetWithText(ElevatedButton, 'Order'));
    await tester.pumpAndSettle();
  });
}
